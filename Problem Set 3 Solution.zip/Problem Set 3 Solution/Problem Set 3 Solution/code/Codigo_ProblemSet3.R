#------------------------------------------------------------------------------#
#                           Universidad de los Andes
#                     Taller de R Estadistica y Programacion
#                                   2023-01
#                         Profesor: Eduard F Martinez
#                                 PROBLEM SET 3
# 
#                               Entregado por:
#                   Andres Felipe Arevalo Mogollon - 201911412
#                   Juan Pablo Villamizar Gonzalez - 201911173
#
#                           Version de RStudio 4.2.2
#------------------------------------------------------------------------------#

#------------------------------------------------------------------------------#

## Configuracion inicial 
rm(list = ls())

# Instalacion de paquetes
#install.packages("haven")
#install.packages("magrittr")
#install.packages("dplyr")
#install.packages("tidyverse")
#install.packages("pacman")
#install.packages("rio")
#install.packages("sf")
#install.packages("leaflet")
#install.packages("rvest")
#install.packages("xml2")
#install.packages("osmdata")
#install.packages("ggsn")

# Instalar las librerías
#install.packages(c("tidy", "skimr", "coefplot", "arrow", "broom", "mfx", "margins", "estimatr", "lmtest", "modelsummary", "stargazer", "leaflet", "tmaptools", "ggmap", "ggspatial", "textcat", "stringi", "tm", "wordcloud"))

# Cargar las librerías
# Se llama a las librerias
library(openxlsx)  # Se agrega el paquete openxlsx
library(haven)
library(magrittr)
library(dplyr)
library(tidyverse)
library(pacman)
library(rio)
library(sf)
library(leaflet)
library(rvest)
library(xml2)
library(osmdata)
library(ggsn)
library(tidy)
library(skimr)
library(coefplot)
library(arrow)
library(broom)
library(mfx)
library(margins)
library(estimatr)
library(lmtest)
library(modelsummary)
library(stargazer)
library(leaflet)
library(tmaptools)
library(ggmap)
library(ggspatial)
library(textcat)
library(stringi)
library(tm)
library(wordcloud)
library(rJava)  # Se agrega el paquete rJava

# Cargar el paquete rJava
library(rJava)
# Establecer la ruta de Java
Sys.setenv(JAVA_HOME = "C:/Program Files/Java/jre1.8.0_301")


#------------------------------------------------------------------------------#
# Punto 1                                                                      #
#------------------------------------------------------------------------------#

#Libreria
p_load(tidyverse,rio,stargazer,coefplot)

## datos
df = import("input/data_regresiones.rds")

## modelos
modelo_1 = lm(price ~ dist_cbd + as.factor(property_type) , data= df)
modelo_2 = lm(price ~ dist_cbd + as.factor(property_type) + rooms , data= df)
modelo_3 = lm(price ~ dist_cbd + as.factor(property_type) + rooms + bathrooms, data= df)

## visualizacion
coefplot(model = modelo_3) + theme_test()

## guardar resultados en Excel
write.xlsx(list(modelo_1, modelo_2, modelo_3), 
           file = "output/resultados_regresiones.xlsx")

#------------------------------------------------------------------------------#
# Punto 2                                                                      #
#------------------------------------------------------------------------------#

bogota <- opq(bbox = getbb("Bogotá Colombia")) %>%
  add_osm_feature(key = "boundary", value = "administrative") %>%
  osmdata_sf()

bogota <- bogota$osm_multipolygons %>% subset(admin_level==9)

## Restaurantes (puntos):

## objeto osm
osm <- opq(bbox = getbb("Bogotá Colombia")) %>%
  add_osm_feature(key="amenity" , value="restaurant") 
class(osm)

## extraer Simple Features Collection
osm_sf <- osm %>% osmdata_sf()
osm_sf

## Obtener un objeto sf
restaurantes <- osm_sf$osm_points 
restaurantes

## Parques (poligonos):

parques <- opq(bbox = getbb("Bogotá Colombia")) %>%
  add_osm_feature(key = "leisure", value = "park") %>%
  osmdata_sf() %>% .$osm_polygons 
parques

## 2.2. Visualizar la info anterior:

##Visualizar los restaurantes (puntos):

leaflet() %>% addTiles() %>% addCircleMarkers(data=restaurantes , col="red")

##Visualizar los parques (poligonos):

leaflet() %>% addTiles() %>% addPolygons(data=parques)

## 2.3. Geocodificar direcciones:

chamois <- geocode_OSM("Calle 85 %9% A - 69, Bogotá", as.sf = T)
chamois

## 2.4. Exportar mapa:

mapa_bog <- ggplot(data = bogota) +
  geom_sf(color = "black") +
  xlab("Longitud") + ylab("Latitud") +
  ggtitle("Mapa de los restaurantes y parques de Bogotá, Colombia", 
          subtitle = "Ubicación del restaurante Chamois (punto verde)") +
  geom_sf(data = restaurantes, color = "red") +
  geom_sf(data = parques, color = "blue") +
  geom_sf(data = chamois, color = "green") +
  scalebar(data = bogota, dist = 5, transform = T, dist_unit = "km") + 
  annotation_scale() + annotation_north_arrow(location = "topleft") + theme_linedraw()

mapa_bog

#------------------------------------------------------------------------------#
# Punto 3                                                                      #
#------------------------------------------------------------------------------#

## PUNTO 3.1

# Cargar el paquete 'rvest'
library(rvest)

url <- "https://es.wikipedia.org/wiki"
pagina <- read_html(url)

## PUNTO 3.2

# Obtener el título de la página
titulo <- html_text(html_nodes(pagina, xpath = "//title"))

# Imprimir el título
cat("Título de la página:", titulo, "\n")

## PUNTO 3.3

# Obtener la tabla de departamentos
tabla_departamentos <- pagina %>% html_table(fill = TRUE)

# Seleccionar la tabla que contiene los departamentos
departamentos <- tabla_departamentos[[1]]  # Ajusta el índice según la posición de la tabla en la página

# Exportar la tabla a un archivo Excel
library(openxlsx)
write.xlsx(departamentos, file ="output/tabla_departamento.xlsx")

## PUNTO 3.4

# Obtener los párrafos del documento
parrafos <- pagina %>% html_nodes("p") %>% html_text()

# Crear un objeto Corpus
corpus <- Corpus(VectorSource(parrafos))

# Preprocesar el Corpus
corpus <- tm_map(corpus, content_transformer(tolower))
corpus <- tm_map(corpus, removePunctuation)
corpus <- tm_map(corpus, removeNumbers)
corpus <- tm_map(corpus, removeWords, stopwords("spanish"))
corpus <- tm_map(corpus, stripWhitespace)

# Crear la matriz término-documento
tdm <- TermDocumentMatrix(corpus)
m <- as.matrix(tdm)

# Calcular la frecuencia de términos
frecuencia <- colSums(m)

# Crear la nube de palabras
set.seed(123)  # Para reproducibilidad
wordcloud(names(frecuencia), frecuencia, scale = c(4, 0.5), random.order = FALSE)

# Exportar la nube de palabras como archivo PNG
dev.copy(png, "output/nube_palabras.png")
dev.off()